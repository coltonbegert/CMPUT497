Enable i2c
https://learn.adafruit.com/adafruits-raspberry-pi-lesson-4-gpio-setup/configuring-i2c

chipcap plugs into i2c 1 (pins 3,5)
https://pinout.xyz

comfast wifi adapter plugs into usb port

```
sudo python rssi_monitor.py [optional filename for output]
```

msp432 + cc3100 flashed with APNode
plug into power and the tests will begin

csv format
timestamp,humidity,temp,rssi
