/* 
 * compat24.h - Linux kernel 2.4 backward compatibility macros & stubs
 */

#ifndef COMPAT24_H
#define COMPAT24_H

/* workqueue compatibility macros */

#include <linux/sched.h>
#define work_struct tq_struct
#define schedule_work schedule_task
#define INIT_WORK INIT_TQUEUE
#define get_seconds() CURRENT_TIME
#define queue_work(x,y) schedule_task(y)
static inline struct workqueue_struct *create_workqueue(char *x) { return NULL; }
#define destroy_workqueue(x) do {} while (0)
#define cancel_delayed_work(x) do {} while (0) /* FIXME? */

/* wait_event compatibility macros */
#define __wait_event_interruptible_timeout(wq, condition, timeout, ret)   \
do {                                                                      \
        ret = 1;                                                		  \
        if (!(condition)) {                                               \
          wait_queue_t __wait;                                            \
          unsigned long expire;                                           \
          init_waitqueue_entry(&__wait, current);                         \
	                                                                  \
          expire = timeout + jiffies;                                     \
          add_wait_queue(&wq, &__wait);                                   \
          for (;;) {                                                      \
                  set_current_state(TASK_INTERRUPTIBLE);                  \
                  if (condition)                                          \
                          break;                                          \
                  if (jiffies > expire) {                                 \
                          ret = 0;			                  \
                          break;                                          \
                  }                                                       \
                  if (!signal_pending(current)) {                         \
                          schedule_timeout(timeout);                      \
                          continue;                                       \
                  }                                                       \
                  ret = -ERESTARTSYS;                                     \
                  break;                                                  \
          }                                                               \
          current->state = TASK_RUNNING;                                  \
          remove_wait_queue(&wq, &__wait);                                \
	}                                                                 \
} while (0)

#define wait_event_interruptible_timeout(wq, condition, timeout)	\
({									\
	long __ret = 1;							\
	if (!(condition))						\
		__wait_event_interruptible_timeout(wq, condition,	\
						timeout, __ret),	\
	__ret;								\
})

#endif /* COMPAT24_H */
