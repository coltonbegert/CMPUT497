/*
 * Original code based on Host AP (software wireless LAN access point) driver 
 * for Intersil Prism2/2.5/3.
 *
 * Copyright (c) 2001-2002, SSH Communications Security Corp and Jouni Malinen
 * <jkmaline@cc.hut.fi>
 * Copyright (c) 2002-2003, Jouni Malinen <jkmaline@cc.hut.fi>
 *
 * Adaption to a generic IEEE 802.11 stack by James Ketrenos 
 * <jketreno@linux.intel.com>
 *
 * Copyright (c) 2004, Intel Corporation
 *
 * Association logic, scanning WX and logics and net queue logic
 * added by Andrea Merello 
 * <andreamrl@tiscali.it>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation. See README and COPYING for
 * more details.
 */
#ifndef IEEE80211_H
#define IEEE80211_H
#define DRV_NAME "ieee80211"

#include <linux/netdevice.h>
#include <linux/wireless.h>
#include <linux/version.h>

/* Include compatibility macros for 2.4 kernels */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
#include "compat24.h"
#endif

#ifndef WIRELESS_SPY
#define WIRELESS_SPY		// enable iwspy support
#endif
#include <net/iw_handler.h>	// new driver API

#define IEEE80211DMESG(x,a...) printk(KERN_INFO "IEEE802.11: " x "\n", ## a)

#define BIT(x) (1 << (x))

#define MAC2STR(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
#define MACSTR "%02x:%02x:%02x:%02x:%02x:%02x"


#ifndef ETH_P_PAE
#define ETH_P_PAE 0x888E /* Port Access Entity (IEEE 802.1X) */
#endif /* ETH_P_PAE */

#define ETH_P_PREAUTH 0x88C7 /* IEEE 802.11i pre-authentication */

#ifndef ETH_P_80211_RAW
#define ETH_P_80211_RAW (ETH_P_ECONET + 1)
#endif

/* IEEE 802.11 defines */

#include "ieee802_11.h"

#define P80211_OUI_LEN 3

#define MAC_HTABLE_ENTRY 10

struct ieee_802_11_snap_header {

        u8    dsap;   /* always 0xAA */
        u8    ssap;   /* always 0xAA */
        u8    ctrl;   /* always 0x03 */
        u8    oui[P80211_OUI_LEN];    /* organizational universal id */

} __attribute__ ((packed));

#define ACK_LEN 10

#define SNAP_SIZE sizeof(struct ieee_802_11_snap_header)

#define WLAN_FC_GET_TYPE(fc) ((fc) & IEEE802_11_FCTL_FTYPE)
#define WLAN_FC_GET_STYPE(fc) ((fc) & IEEE802_11_FCTL_STYPE)

#define WLAN_GET_SEQ_FRAG(seq) ((seq) & IEEE802_11_SCTL_FRAG)
#define WLAN_GET_SEQ_SEQ(seq)  ((seq) & IEEE802_11_SCTL_SEQ)

/* Authentication algorithms */
#define WLAN_AUTH_OPEN 0
#define WLAN_AUTH_SHARED_KEY 1

#define WLAN_AUTH_CHALLENGE_LEN 128

#define WLAN_CAPABILITY_BSS BIT(0)
#define WLAN_CAPABILITY_IBSS BIT(1)
#define WLAN_CAPABILITY_CF_POLLABLE BIT(2)
#define WLAN_CAPABILITY_CF_POLL_REQUEST BIT(3)
#define WLAN_CAPABILITY_PRIVACY BIT(4)
#define WLAN_CAPABILITY_SHORT_PREAMBLE BIT(5)
#define WLAN_CAPABILITY_PBCC BIT(6)
#define WLAN_CAPABILITY_CHANNEL_AGILITY BIT(7)

/* Status codes */
#define WLAN_STATUS_SUCCESS 0
#define WLAN_STATUS_UNSPECIFIED_FAILURE 1
#define WLAN_STATUS_CAPS_UNSUPPORTED 10
#define WLAN_STATUS_REASSOC_NO_ASSOC 11
#define WLAN_STATUS_ASSOC_DENIED_UNSPEC 12
#define WLAN_STATUS_NOT_SUPPORTED_AUTH_ALG 13
#define WLAN_STATUS_UNKNOWN_AUTH_TRANSACTION 14
#define WLAN_STATUS_CHALLENGE_FAIL 15
#define WLAN_STATUS_AUTH_TIMEOUT 16
#define WLAN_STATUS_AP_UNABLE_TO_HANDLE_NEW_STA 17
#define WLAN_STATUS_ASSOC_DENIED_RATES 18
/* 802.11b */
#define WLAN_STATUS_ASSOC_DENIED_NOSHORT 19
#define WLAN_STATUS_ASSOC_DENIED_NOPBCC 20
#define WLAN_STATUS_ASSOC_DENIED_NOAGILITY 21

/* Reason codes */
#define WLAN_REASON_UNSPECIFIED 1
#define WLAN_REASON_PREV_AUTH_NOT_VALID 2
#define WLAN_REASON_DEAUTH_LEAVING 3
#define WLAN_REASON_DISASSOC_DUE_TO_INACTIVITY 4
#define WLAN_REASON_DISASSOC_AP_BUSY 5
#define WLAN_REASON_CLASS2_FRAME_FROM_NONAUTH_STA 6
#define WLAN_REASON_CLASS3_FRAME_FROM_NONASSOC_STA 7
#define WLAN_REASON_DISASSOC_STA_HAS_LEFT 8
#define WLAN_REASON_STA_REQ_ASSOC_WITHOUT_AUTH 9


/* Information Element IDs */
#define WLAN_EID_SSID 0
#define WLAN_EID_SUPP_RATES 1
#define WLAN_EID_FH_PARAMS 2
#define WLAN_EID_DS_PARAMS 3
#define WLAN_EID_CF_PARAMS 4
#define WLAN_EID_TIM 5
#define WLAN_EID_IBSS_PARAMS 6
#define WLAN_EID_CHALLENGE 16
#define WLAN_EID_RSN 48
#define WLAN_EID_GENERIC 221

/* frame type */
#define WLAN_FC_TYPE_MGMT 0
#define WLAN_FC_TYPE_CTRL 1
#define WLAN_FC_TYPE_DATA 2
#if 0
/* management */
#define WLAN_FC_STYPE_ASSOC_REQ 0
#define WLAN_FC_STYPE_ASSOC_RESP 1
#define WLAN_FC_STYPE_REASSOC_REQ 2
#define WLAN_FC_STYPE_REASSOC_RESP 3
#define WLAN_FC_STYPE_PROBE_REQ 4
#define WLAN_FC_STYPE_PROBE_RESP 5
#define WLAN_FC_STYPE_BEACON 8
#define WLAN_FC_STYPE_ATIM 9
#define WLAN_FC_STYPE_DISASSOC 10
#define WLAN_FC_STYPE_AUTH 11
#define WLAN_FC_STYPE_DEAUTH 12
#endif
#define WLAN_FC_ISWEP BIT(14)

#define IEEE80211_MGMT_HDR_LEN 24
#define IEEE80211_DATA_HDR3_LEN 24
#define IEEE80211_DATA_HDR4_LEN 30

#define SCAN_JIFFI 6000 //FIXME: these are 8 sec on x86, make it arch ind.

/* carrier */
#define WLAN_LINK_ASSOCIATED 2
#define WLAN_LINK_ASSOCIATING 1
#define WLAN_LINK_NONE 0

/*Association states*/
#define ASSOC_REQ 0
#define ASSOC_AUTH 1
#define ASSOC_SUCCESS 2

extern const long wlan_frequencies[];


struct ieee_tx_beacon
{
	u16 frame_control;
	u16 duration_id;
	u8 addr1[6];
	u8 addr2[6];
	u8 addr3[6];
	u16 seq_ctrl;
	u64 timestamp;
	u16 interval;
	u16 capability;
	
} __attribute__ ((packed));



struct ieee80211_hdr {
	u16 frame_control;
	u16 duration_id;
	u8 addr1[6];
	u8 addr2[6];
	u8 addr3[6];
	u16 seq_ctrl;
	u8 addr4[6];
} __attribute__ ((packed));

/* NOTE: This data is for statistical purposes; not all hardware provides this
 *       information for frames received.  Not setting these will not cause
 *       any adverse affects. */
struct ieee80211_rx_stats {
	u32 mac_time;
	u8 signal;
	u8 noise;
	u16 rate; /* in 100 kbps */
};

/* IEEE 802.11 requires that STA supports concurrent reception of at least
 * three fragmented frames. This define can be increased to support more
 * concurrent frames, but it should be noted that each entry can consume about
 * 2 kB of RAM and increasing cache size will slow down frame reassembly. */
#define IEEE80211_FRAG_CACHE_LEN 4

struct ieee80211_frag_entry {
	unsigned long first_frag_time;
	unsigned int seq;
	unsigned int last_frag;
	struct sk_buff *skb;
	u8 src_addr[ETH_ALEN];
	u8 dst_addr[ETH_ALEN];
};

struct ieee80211_stats {
	unsigned int tx_unicast_frames;
	unsigned int tx_multicast_frames;
	unsigned int tx_fragments;
	unsigned int tx_unicast_octets;
	unsigned int tx_multicast_octets;
	unsigned int tx_deferred_transmissions;
	unsigned int tx_single_retry_frames;
	unsigned int tx_multiple_retry_frames;
	unsigned int tx_retry_limit_exceeded;
	unsigned int tx_discards;
	unsigned int rx_unicast_frames;
	unsigned int rx_multicast_frames;
	unsigned int rx_fragments;
	unsigned int rx_unicast_octets;
	unsigned int rx_multicast_octets;
	unsigned int rx_fcs_errors;
	unsigned int rx_discards_no_buffer;
	unsigned int tx_discards_wrong_sa;
	unsigned int rx_discards_wep_undecryptable;
	unsigned int rx_message_in_msg_fragments;
	unsigned int rx_message_in_bad_msg_fragments;
	unsigned int aut_noresp;
	unsigned int ass_noresp;
	unsigned int tx_aut;
	unsigned int tx_ass;
	unsigned int rx_ass_ok;
	unsigned int rx_aut_ok;
	unsigned int rx_aut_err;
	unsigned int rx_ass_err;
	unsigned int tx_probe;
	unsigned int rx_probe;
	unsigned long swtxstop;
	unsigned long swtxawake;
	unsigned long rx_auth_rq;
	unsigned long rx_assoc_rq;
	unsigned long reassoc;
	unsigned long tx_probe_rq;
	
};

struct ieee80211_device;

#include "ieee80211_crypt.h"
 
#define SEC_KEY_1         BIT(0)
#define SEC_KEY_2         BIT(1)
#define SEC_KEY_3         BIT(2)
#define SEC_KEY_4         BIT(3)
#define SEC_ACTIVE_KEY    BIT(4)
#define SEC_AUTH_MODE     BIT(5)
#define SEC_UNICAST_GROUP BIT(6)
#define SEC_LEVEL         BIT(7)
#define SEC_ENABLED       BIT(8)

#define SEC_LEVEL_0      0 /* None */
#define SEC_LEVEL_1      1 /* WEP 40 and 104 bit */
#define SEC_LEVEL_2      2 /* Level 1 + TKIP */
#define SEC_LEVEL_2_CKIP 3 /* Level 1 + CKIP */
#define SEC_LEVEL_3      4 /* Level 2 + CCMP */

#define WEP_KEYS 4
#define WEP_KEY_LEN 13

struct ieee80211_security {
	u16 active_key:1, 
            enabled:1, 
	    auth_mode:2, 
            auth_algo:4, 
            unicast_uses_group:1;
	u8 key_sizes[WEP_KEYS];
	u8 keys[WEP_KEYS][WEP_KEY_LEN];
	u8 level;
	u16 flags;
} __attribute__ ((packed));


/*

 802.11 data frame from AP

      ,-------------------------------------------------------------------.
Bytes |  2   |  2   |    6    |    6    |    6    |  2   | 0..2312 |   4  |
      |------|------|---------|---------|---------|------|---------|------|
Desc. | ctrl | dura |  DA/RA  |   TA    |    SA   | Sequ |  frame  |  fcs |
      |      | tion | (BSSID) |         |         | ence |  data   |      |
      `-------------------------------------------------------------------'

Total: 28-2340 bytes

*/

struct ieee80211_header_data {
	u16 frame_control;
	u16 duration_id;
	u8 addr1[6];
	u8 addr2[6];
	u8 addr3[6];
	u16 seq_ctrl;
}__attribute__ ((packed));

#define BEACON_PROBE_SSID_ID_POSITION 12

/* Management Frame Information Element Types */
#define MFIE_TYPE_SSID       0
#define MFIE_TYPE_RATES      1
#define MFIE_TYPE_FH_SET     2
#define MFIE_TYPE_DS_SET     3
#define MFIE_TYPE_CF_SET     4
#define MFIE_TYPE_TIM        5
#define MFIE_TYPE_IBSS_SET   6
#define MFIE_TYPE_CHALLENGE  16

struct ieee80211_info_element_hdr {
	u8 id;
	u8 len;
} __attribute__ ((packed));

struct ieee80211_info_element {
	u8 id;
	u8 len;
	u8 data[0];
} __attribute__ ((packed));

/*
 * These are the data types that can make up management packets
 *
	u16 auth_algorithm;
	u16 auth_sequence;
	u16 beacon_interval;
	u16 capability;
	u8 current_ap[ETH_ALEN];
	u16 listen_interval;
	struct {
		u16 association_id:14, reserved:2;
	} __attribute__ ((packed));
	u32 time_stamp[2];
	u16 reason;
	u16 status;
*/

struct ieee80211_authentication {
	struct ieee80211_header_data header;
	u16 algorithm;
	u16 transaction;
	u16 status;
	//struct ieee80211_info_element info_element;
} __attribute__ ((packed));

struct ieee80211_probe_request {
	struct ieee80211_header_data header;
	/*struct ieee80211_info_element info_element;*/
} __attribute__ ((packed));

struct ieee80211_probe_response {
	struct ieee80211_header_data header;
	u32 time_stamp[2];
	u16 beacon_interval;
	u16 capability;
	struct ieee80211_info_element info_element;
} __attribute__ ((packed));

struct ieee80211_assoc_request_frame {
	u16 capability;
	u16 listen_interval;
	u8 current_ap[ETH_ALEN];
	struct ieee80211_info_element info_element;
} __attribute__ ((packed));

struct ieee80211_association_request_hdr{
	u16 frame_control;
	u16 duration;
	u8 addr1[ETH_ALEN];
	u8 addr2[ETH_ALEN];
	u8 addr3[ETH_ALEN];
	u16 seq;
	u16 capability;
	u16 listen_interval;
	
} __attribute__ ((packed));

struct ieee80211_association_response_hdr{
	u16 frame_control;
	u16 duration;
	u8 addr1[ETH_ALEN];
	u8 addr2[ETH_ALEN];
	u8 addr3[ETH_ALEN];
	u16 seq;
	u16 capability;
	u16 status;
	u16 id;
	
} __attribute__ ((packed));

/* SWEEP TABLE ENTRIES NUMBER*/
#define MAX_SWEEP_TAB_ENTRIES		  42
#define MAX_SWEEP_TAB_ENTRIES_PER_PACKET  7
#define MAX_RATES_LENGTH                  ((u8)8)
#define MAX_BEACON_COUNT                  128

#ifdef IW_ESSID_MAX_SIZE
#define SSID_LENGTH IW_ESSID_MAX_SIZE
#else
#define SSID_LENGTH                       ((u8)32)
#endif

#define CRC_LENGTH                 4U

#define SSID_11B_RATE_1MB          0x0001
#define SSID_11B_RATE_2MB          0x0002
#define SSID_11B_RATE_5MB          0x0004
#define SSID_11B_RATE_11MB         0x0008
#define SSID_11B_RATE_22MB         0x0010
#define BEACON_CAPABILITY_WEP 	   0x0010

struct ieee80211_beacon {
	u8 bssid[ETH_ALEN];
	u8 ssid_len;
	s8 rssi;
	u16 capability;
	u8 channel;
	u8 rates[MAX_RATES_LENGTH];
	u8 rates_len;
	u32 last_scanned;
	/* Ensure null-terminated for any debug msgs */
	u8 ssid[SSID_LENGTH + 1];
	u8 quality;
	u16 interval;
	struct list_head list;
};



struct ieee80211_helper_functions {
	void (*set_security)(struct ieee80211_device *ieee, 
			     struct ieee80211_security *sec);

	/* these functions are defined in hardware model specific files
	 * (hostap_{cs,plx,pci}.c */
	int (*card_present)(struct ieee80211_device *ieee);
	void (*cor_sreset)(struct ieee80211_device *ieee);
	int (*dev_open)(struct ieee80211_device *ieee);
	int (*dev_close)(struct ieee80211_device *ieee);
	void (*genesis_reset)(struct ieee80211_device *ieee, int hcr);

	
	/* Turn on unencrypted packet filtering at the HW level */
	void (*set_unencrypted_filter)(struct ieee80211_device *ieee, int flag);

	/* the following functions are from hostap_hw.c, but they may have some
	 * hardware model specific code */

	int (*hw_enable)(struct net_device *dev, int initial);
	int (*hw_config)(struct net_device *dev, int initial);
	void (*hw_reset)(struct net_device *dev);
	void (*hw_shutdown)(struct net_device *dev, int no_disable);
	int (*reset_port)(struct net_device *dev);
	/*int (*tx)(struct sk_buff *skb, struct net_device *dev);*/
	void (*schedule_reset)(struct ieee80211_device *ieee);
	int (*tx_80211)(struct sk_buff *skb, struct net_device *dev);
	void (*set_chan)(struct net_device *dev,short ch);
	void (*start_scan)(struct net_device *dev);
	void (*stop_scan)(struct net_device *dev);
	void (*associate)(struct net_device *dev, struct ieee80211_beacon *beacon);
	void (*hard_data_xmit)(struct net_device *dev,struct sk_buff *skb,short morefrag);
	void (*data_poll_hard_stop)(struct net_device *dev);
	void (*data_poll_hard_resume)(struct net_device *dev);
};

struct ieee80211_txb {
	u8 nr_frags;
	u8 encrypted;
	u16 reserved;
	u16 frag_size;
	u16 payload_size;
	struct sk_buff *fragments[0];
};

typedef struct tx_pending_t{
	int frag;
	struct ieee80211_txb *txb;
}tx_pending_t;


typedef struct mac_htable_t {
	u8 adr[ETH_ALEN];
	unsigned long time;
	struct mac_htable_t *next;

} mac_htable_t;

struct ieee80211_device {
	struct net_device *dev;

	/* Bookkeeping structures */
	struct net_device_stats stats;
	struct ieee80211_stats ieee_stats;
	void *priv;

	int iw_mode; /* operating mode (IW_MODE_*) */

	spinlock_t lock;
	spinlock_t irq_lock;
	
	struct list_head beacons;
	
	/*used by the association workqueue, when associated contains info on the NET*/
	struct ieee80211_beacon *ass_beacon; 	
	struct timer_list associate_timer;

	/*struct workqueue_struct *workqueue;
	struct work_struct associate_tasklet;
	*/
	unsigned long associate_seq;
	int assoc_id;
	short associate_state;
	//wait_queue_head_t assoc_queue;
	int link_state;
	u16 seq_ctrl; //this contains the seq number (not the frag)
	//u8 *ssid; //null if noone request to associate, point to essid if set by iwconfig
	u8 ssid[SSID_LENGTH + 1];
	int sifs_time;
	short rate;
	int tx_payload_only; /* set to 1 if HW only expects the Tx SKB 
			      * to contain the payload (vs. a fully configured
			      * 802.11 header for a data frame) */
	short queue_stop;
	
	struct  tx_pending_t tx_pending;
	/* WEP and other encryption related settings at the device level */
	int open_wep; /* Set to 1 to allow unencrypted frames */
	short hw_wep; /* Set to let TX reserve space for IV and ICV, and RX discard IV and ICV, assume the HW decrypt/encrypt packets*/
	short hw_seq;
	int reset_on_keychange; /* Set to 1 if the HW needs to be reset on
				 * WEP key changes */

	/* If the host performs {en,de}cryption, then set to 1 */
	int host_encrypt;
	int host_decrypt;

	int ieee_802_1x; /* is IEEE 802.1X used */

	struct list_head crypt_deinit_list;
	struct ieee80211_crypt_data *crypt[WEP_KEYS];
	int tx_keyidx; /* default TX key index (crypt[tx_keyidx]) */
	struct timer_list crypt_deinit_timer;

	int bcrx_sta_key; /* use individual keys to override default keys even
			   * with RX of broad/multicast frames */

	/* Fragmentation structures */
	struct ieee80211_frag_entry frag_cache[IEEE80211_FRAG_CACHE_LEN];
	unsigned int frag_next_idx;
	u16 fts; /* Fragmentation Threshold */

	/* Callback vtable */
	struct ieee80211_helper_functions *func;
	
	u8 beacon_cell_ssid[ETH_ALEN];	
	u8 *master_essid;
	u16 beacon_interval;
	u8 master_chan;
	u8 ap[ETH_ALEN];
	
	struct mac_htable_t *bridge_htable[MAC_HTABLE_ENTRY];
	struct mac_htable_t *assoc_htable[MAC_HTABLE_ENTRY];
};


extern inline int ieee80211_get_hdrlen(u16 fc)
{
	int hdrlen = 24;

	switch (WLAN_FC_GET_TYPE(fc)) {
	case IEEE802_11_FTYPE_DATA:
		if ((fc & IEEE802_11_FCTL_FROMDS) && (fc & IEEE802_11_FCTL_TODS))
			hdrlen = 30; /* Addr4 */
		break;
	case IEEE802_11_FTYPE_CTL:
		switch (WLAN_FC_GET_STYPE(fc)) {
		case IEEE802_11_STYPE_CTS:
		case IEEE802_11_STYPE_ACK:
			hdrlen = 10;
			break;
		default:
			hdrlen = 16;
			break;
		}
		break;
	}

	return hdrlen;
}

/* ieee80211.c */
extern struct ieee80211_device * ieee80211_r8180_alloc(struct net_device *dev,
						 void *priv);
extern void ieee80211_r8180_free(struct ieee80211_device *ieee);

extern int ieee80211_set_encryption(struct ieee80211_device *ieee);

extern void ieee80211_associate_step2(struct ieee80211_device *ieee);

extern void ieee80211_associate_step1(struct ieee80211_device *ieee);

extern void ieee80211_associate_complete(struct ieee80211_device *ieee);

extern void ieee80211_associate_abort(struct ieee80211_device *ieee);

extern void ieee80211_probe_hidden(struct ieee80211_device *ieee);

void ieee80211_resp_to_auth(struct ieee80211_device *ieee, int s, u8* dest);

void ieee80211_resp_to_assoc_rq(struct ieee80211_device *ieee, u8* dest);

/* ieee80211_tx.c */

#if 0
extern struct ieee80211_txb *ieee80211_r8180_skb_to_txb(struct ieee80211_device *ieee, 
						  struct sk_buff *skb);
extern void ieee80211_r8180_txb_free(struct ieee80211_txb *);


extern struct ieee80211_txb *ieee80211_r8180_alloc_txb(int nr_frags, int txb_size,
				  int gfp_mask);
#endif

/* ieee80211_rx.c */
extern int ieee80211_r8180_rx(struct ieee80211_device *ieee, struct sk_buff *skb,
			struct ieee80211_rx_stats *rx_stats);

/* iee80211_wx.c */
extern int ieee80211_r8180_wx_set_encode(struct ieee80211_device *ieee, 
				   struct iw_request_info *info, 
				   union iwreq_data *wrqu, char *key);
extern int ieee80211_r8180_wx_get_encode(struct ieee80211_device *ieee, 
				   struct iw_request_info *info, 
				   union iwreq_data *wrqu, char *key);
				   /* iee80211_wx.c */
extern int ieee80211_r8180_wx_get_scan(struct ieee80211_device *ieee,struct iw_request_info *a,union iwreq_data *wrqu,char *extra);

extern  int ieee80211_r8180_wx_get_essid(struct ieee80211_device *ieee, struct iw_request_info *a,union iwreq_data *wrqu,char *b);

extern  int ieee80211_r8180_wx_set_essid(struct ieee80211_device *ieee, struct iw_request_info *a,union iwreq_data *wrqu,char *b);

extern  int ieee80211_r8180_wx_get_rate(struct ieee80211_device *ieee, struct iw_request_info *a,union iwreq_data *wrqu,char *b);

extern  int ieee80211_r8180_wx_set_rate(struct ieee80211_device *ieee, struct iw_request_info *a,union iwreq_data *wrqu,char *b);


extern void ieee80211_new_net(struct ieee80211_device *ieee, struct ieee80211_beacon *beacon);

extern void ieee80211_r8180_set_master_essid(struct ieee80211_device *ieee, char* essid, int len);

extern void ieee80211_resp_to_probe(struct ieee80211_device *ieee, u8 *dest);

extern void ieee80211_r8180_stop_queue(struct ieee80211_device *ieee);

extern void ieee80211_r8180_wake_queue(struct ieee80211_device *ieee);

extern void ieee80211_r8180_reset_queue(struct ieee80211_device *ieee);

extern int ieee80211_r8180_8023_hardstartxmit(struct sk_buff *skb, struct ieee80211_device *ieee);

extern void ieee80211_r8180_flush_scan(struct ieee80211_device *ieee);

extern int ieee80211_r8180_wx_set_wap(struct ieee80211_device *ieee,
			 struct iw_request_info *info,
			 union iwreq_data *awrq,
			 char *extra);

extern short is_associated(struct ieee80211_device *ieee,u8 *adr);

extern short is_bridged(struct ieee80211_device *ieee,u8 *adr);

extern short add_associate(struct ieee80211_device *ieee,u8 *adr);

extern short add_bridged(struct ieee80211_device *ieee,u8 *adr);

extern short is_broadcast(u8 *adr);

extern short is_multicast(u8 *adr);


#endif /* IEEE80211_H */
