/* 
   This is part of rtl8180 OpenSource driver.
   Copyright (C) Andrea Merello 2004-2005  <andreamrl@tiscali.it> 
   Released under the terms of GPL (General Public Licence)
   
   Parts of this driver are based on the GPL part of the 
   official realtek driver
   
   Parts of this driver are based on the rtl8180 driver skeleton 
   from Patric Schenke & Andres Salomon
   
   Parts of this driver are based on the Intel Pro Wireless 2100 GPL driver
   
   We want to tanks the Authors of those projects and the Ndiswrapper 
   project Authors.
*/

#ifndef R8180H
#define R8180H


#define RTL8180_MODULE_NAME "rtl8180"
#define DMESG(x,a...) printk(KERN_INFO RTL8180_MODULE_NAME ": " x "\n", ## a)
#define DMESGW(x,a...) printk(KERN_WARNING RTL8180_MODULE_NAME ": " x "\n", ## a)

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/config.h>
#include <linux/init.h>
#include <linux/ioport.h>
#include <linux/sched.h>
#include <linux/types.h>
#include <linux/slab.h>
#include <linux/netdevice.h>
#include <linux/pci.h>
#include <linux/etherdevice.h>
#include <linux/delay.h>
#include <linux/rtnetlink.h>	//for rtnl_lock()
#include <linux/wireless.h>
#include <linux/timer.h>
#include <linux/proc_fs.h>	// Necessary because we use the proc fs
#include <linux/if_arp.h>
#include <linux/random.h>
#include <asm/io.h>
#include <asm/semaphore.h>

#include "ieee80211.h"

#define EPROM_93c46 0
#define EPROM_93c56 1

#define DEFAULT_FRAG_THRESHOLD 2342U
#define MIN_FRAG_THRESHOLD     256U
#define	MAX_FRAG_THRESHOLD     2342U
#define DEFAULT_BEACONINTERVAL 0x64U
#define DEFAULT_BEACON_ESSID "Rtl8180"
#define DEFAULT_BASICRATE 0x0
#define DEFAULT_SSID ""
#define DEFAULT_RETRY_RTS 7
#define DEFAULT_RETRY_DATA 7
#define PRISM_HDR_SIZE 64

typedef struct buffer
{
	struct buffer *next;
	u32 *buf;
	dma_addr_t dma;
} buffer;

#if 0

typedef struct tx_pendingbuf
{
	struct ieee80211_txb *txb;
	short ispending;
	short descfrag;
} tx_pendigbuf;

#endif

typedef struct Stats
{
	unsigned long txrdu;
	unsigned long rxrdu;
	unsigned long rxnolast;
	unsigned long rxnodata;
	unsigned long rxreset;
	unsigned long rxwrkaround;
	unsigned long rxnopointer;
	unsigned long txnperr;
	unsigned long txresumed;
	unsigned long rxerr;
	unsigned long rxoverflow;
	unsigned long rxint;
	unsigned long txnpokint;
	unsigned long txhpokint;
	unsigned long txhperr;
	unsigned long ints;
	unsigned long shints;
	unsigned long txoverflow;
	unsigned long rxdmafail;
	unsigned long txbeacon;
	unsigned long txbeaconerr;
	unsigned long txlpokint;
	unsigned long txlperr;
} Stats;



typedef struct r8180_priv
{
	struct pci_dev *pdev;
	short epromtype;
	int irq;
	struct ieee80211_device *ieee80211;
	
	short card_8185;
	short hw_plcp_len;
		
	spinlock_t irq_lock;
	spinlock_t irq_th_lock;
	spinlock_t tx_lock;
	
	u16 irq_mask;
	struct net_device *dev;
	short chan;
	u8 chtxpwr[15]; //channels from 1 to 14, 0 not used
	u8 challow[15]; //channels from 1 to 14, 0 not used
	short up;
	short crcmon; //if 1 allow bad crc frame reception in monitor mode
	short prism_hdr;
	
	struct timer_list scan_timer;
	/*short scanpending;
	short stopscan;*/
	spinlock_t scan_lock;
	u8 active_probe;
	//u8 active_scan_num;
	struct semaphore wx_sem;
	short hw_wep;
		
	short digphy;
	short antb;
	short diversity;
	u8 cs_treshold;
	short rcr_csense;
	short rf_chip;
	u32 key0[4];
	void (*rf_set_chan)(struct net_device *dev,short ch);
	void (*rf_close)(struct net_device *dev);
	void (*rf_init)(struct net_device *dev);
	//short rate;
	short promisc;	
	/*stats*/
	struct Stats stats;
	struct iw_statistics wstats;
	struct proc_dir_entry *dir_dev;
	
	/*RX stuff*/
	u32 *rxring;
	u32 *rxringtail;
	dma_addr_t rxringdma;
	struct buffer *rxbuffer;
	struct buffer *rxbufferhead;
	int rxringcount;
	u16 rxbuffersize;
	
	struct sk_buff *rx_skb; 

	short rx_skb_complete;

	u32 rx_prevlen;
	
	/*TX stuff*/
	u32 *txlpring;
	u32 *txhpring;
	u32 *txnpring;
	dma_addr_t txlpringdma;
	dma_addr_t txhpringdma;
	dma_addr_t txnpringdma;
	u32 *txlpringtail;
	u32 *txhpringtail;
	u32 *txnpringtail;
	u32 *txlpringhead;
	u32 *txhpringhead;
	u32 *txnpringhead;
	struct buffer *txlpbufs;
	struct buffer *txhpbufs;
	struct buffer *txnpbufs;
	struct buffer *txlpbufstail;
	struct buffer *txhpbufstail;
	struct buffer *txnpbufstail;
	int txringcount;
	int txbuffsize;
	//struct tx_pendingbuf txnp_pending;
	struct tasklet_struct irq_tx_tasklet;
	struct tasklet_struct irq_rx_tasklet;
	u8 dma_poll_mask;
	//short tx_suspend;
	
	/* adhoc/master mode stuff */
	u32 *txbeacontail;
	dma_addr_t txbeaconringdma;
	u32 *txbeaconring;
	int txbeaconcount;
	struct ieee_tx_beacon *beacon_buf;
	//char *master_essid;
	dma_addr_t beacondmabuf;
	//u16 master_beaconinterval;
	u32 master_beaconsize;
	//u16 beacon_interval;
	u8 basic_rate;
	u8 retry_data;
	u8 retry_rts;
	
	short wq_hurryup;
	struct workqueue_struct *workqueue;
	struct work_struct IBSS_work;
	
}r8180_priv;



#define LOW_PRIORITY 1
#define HI_PRIORITY 2
#define NORM_PRIORITY 0


short rtl8180_tx(struct net_device *dev,u32* skbuf, int len,int priority,short morefrag,short fragdesc);
void rtl8180_BSS_join(struct net_device *dev, struct ieee80211_beacon *beacon);

u8 read_nic_byte(struct net_device *dev, int x);
u32 read_nic_dword(struct net_device *dev, int x);
u16 read_nic_word(struct net_device *dev, int x) ;
void write_nic_byte(struct net_device *dev, int x,u8 y);
void write_nic_word(struct net_device *dev, int x,u16 y);
void write_nic_dword(struct net_device *dev, int x,u32 y);

void rtl8180_rtx_disable(struct net_device *);
void rtl8180_rx_enable(struct net_device *);
void rtl8180_tx_enable(struct net_device *);
void rtl8180_start_scanning(struct net_device *dev);
void rtl8180_stop_scanning(struct net_device *dev);
void rtl8180_disassociate(struct net_device *dev);
//void fix_rx_fifo(struct net_device *dev);
void rtl8180_set_anaparam(struct net_device *dev,u32 a);
void rtl8180_set_hw_wep(struct net_device *dev);
void rtl8180_no_hw_wep(struct net_device *dev);
//void rtl8180_BSS_create(struct net_device *dev);
void rtl8180_beacon_tx_disable(struct net_device *dev);
void rtl8180_beacon_rx_disable(struct net_device *dev);
void rtl8180_conttx_enable(struct net_device *dev);
void rtl8180_conttx_disable(struct net_device *dev);
int rtl8180_down(struct net_device *dev);
int rtl8180_up(struct net_device *dev);
void rtl8180_commit(struct net_device *dev);
void rtl8180_set_chan(struct net_device *dev,short ch);
void rtl8180_set_master_essid(struct net_device *dev,char *essid);
void rtl8180_update_beacon_security(struct net_device *dev);
void write_phy(struct net_device *dev, u8 adr, u8 data);
void IBSS_randomize_cell(struct net_device *dev);
#endif
